﻿namespace PokemonGo.RocketAPI.Enums
{
    public enum AuthType
    {
        Google,
        Ptc
    }
}