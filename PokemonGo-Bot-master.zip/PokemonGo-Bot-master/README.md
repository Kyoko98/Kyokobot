# Donate
  - Every Donation will help the Project!
  - 
[![PayPal Donation](https://www.paypalobjects.com/en_US/DE/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RUNUBQEANCAGQ)
  - Bitcoin: 1PdQK9hhdLy83UKVQVop8bjnkSw17hj5z4

# Credits to:
  - https://github.com/NECROBOTIO/NecroBot <- Without him this bot wont be alive, so please share some love! His Bot is awesome too!
  - https://github.com/Linewalker/POGOProtos-0.31.0
  - https://github.com/AeonLucid/POGOProtos
  - https://github.com/FeroxRev/Pokemon-Go-Rocket-API
  - https://github.com/UntilSunrise/Pokemon-Go-Rocket-API
  - https://github.com/martin-podlubny
  - https://github.com/Spegeli/Pokemon-Go-Rocket-API

# Special thanks:
  - To FeroxRev, for this AMAZING work!
  - To Necrobot, for this awesome API fix, where we used some pieces of.
  

# Translations
  - English: https://github.com/Ar1i/ & Greengold
  - German: https://github.com/IceQ1337/
  - Portuguese: https://github.com/m-a-r-c-e-l-o
  - Turkish: https://github.com/HaydarOzturk
  - Russian: https://github.com/MrFallen
  - Spanish: max783
